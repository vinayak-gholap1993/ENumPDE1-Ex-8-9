#include "exercise8.h"
#include "implementation.h"
#include <iostream>

#include "list.h"


#define MAX_IT 50000

#define err_exit(msg) \
  { fprintf(stderr, "ERROR: %s (%s:%d)\n", msg, __FILE__, __LINE__); exit(1); }


extern "C" void getMesh(mesh * m, size_t n)
{
  /* Call to C++-routine */
  /* getMesh(m, n); */

   size_t coord_index, triangle_index;
   double x,y;
   size_t i,j;

   double h = 1.0/ n;
   double hsquare = h * h;
   double h_i[2];
   h_i[0] = h + hsquare;
   h_i[1] = h - hsquare;

   m->n_vertices = (n+1) * (n+1);
   m->n_triangles = 2 * n * n;

   //memory allocation of struct members

   m->coords = new double [2 * m->n_vertices];
   m->t2v = new size_t [3 * m->n_triangles];
   m->id_v = new unsigned char [m->n_vertices];

    for(i =0, y = 0.0; i <= n; ++i)
    {
        for(j=0, x = 0.0; j<= n ; ++j)
        {
            coord_index = i * (n+1) + j;        //lexicographic ordering of nodal points

            m->coords[2 * coord_index] = x;
            m->coords[2 * coord_index +1] = y;

            m->id_v[coord_index] = (j == 0) ? 4 : (j == n) ? 2 : (i == 0) ? 1 : (i == n) ? 3 : 0;

            x += h_i[j % 2];
        }
        y += h_i[i % 2];
    }

    for(i=0; i < n; ++i)
    {
        for(j=0; j < n; ++j )
        {
            triangle_index = 2 * (i * n+ j);

            // each quadrilateral will have 2 triangles
            // lower right triangle and upper left triangle

            //upper left triangle filling for t2v with coords (i,j), (i+1,j+1), (i+1,j) with counter clockwise ordering

            m->t2v[3 * triangle_index] = i * (n+1) + j;
            m->t2v[3 * triangle_index + 1] = (i+1) * (n+1) + (j+1);
            m->t2v[3 * triangle_index + 2] = (i+1) * (n+1) + j;

            //lower right triangle filling for t2v with coords (i,j), (i,j+1), (i+1,j+1) with counter clockwise ordering

            ++triangle_index;

            m->t2v[3 * triangle_index] = i * (n+1) + j;
            m->t2v[3 * triangle_index + 1] = i * (n+1) + (j+1);
            m->t2v[3 * triangle_index + 2] = (i+1) * (n+1) + (j+1);


        }
    }

}

extern "C" void initMatrix(crs_matrix * mat, mesh const * m)
{

    size_t vertex, triangle;
    size_t nnz = 0, ind;
    List * vertex2vertex_lists;
    list_element * iterator;

    vertex2vertex_lists = new List [m->n_vertices];
    if (vertex2vertex_lists == NULL)
        err_exit("Lists allocation failed");

    for (vertex = 0; vertex < m->n_vertices; ++vertex)
    {
      init_list(&vertex2vertex_lists[vertex]);
    }

    for (triangle = 0; triangle < m->n_triangles; ++triangle)
    {

      for (size_t i = 0; i < 3; ++i)
      {
        vertex = m->t2v[3 * triangle + i];

        for (size_t j = 0; j < 3; ++j)
        {
          insert_list(&vertex2vertex_lists[vertex], m->t2v[3 * triangle + j]);
        }
      }
    }

    for (vertex = 0; vertex < m->n_vertices; ++vertex)
    {
      nnz += vertex2vertex_lists[vertex].length;
    }

    mat->n_rows = mat->n_cols = m->n_vertices;
    mat->val = new double [nnz];
    mat->rowPtr = new size_t  [mat->n_rows + 1];
    mat->colInd = new size_t  [nnz];
    if (mat->val == NULL || mat->rowPtr == NULL || mat->colInd == NULL)
      err_exit("CRS-matrix allocation failed");

    //memset(mat->val, 0, sizeof(double) * nnz);
    mat->val = new double [nnz]();

    mat->rowPtr[0] = 0;

      for (vertex = 0; vertex < m->n_vertices; ++vertex)
      {
        ind = mat->rowPtr[vertex];
        iterator = vertex2vertex_lists[vertex].begin;
        while (iterator != NULL)
        {
          mat->colInd[ind++] = iterator->node_val;
          iterator = iterator->next;
        }
        mat->rowPtr[vertex+1] = ind;
      }
    //delete vertex2vertex_lists;
}

extern "C" void getLocalStiffness(double local_stiffness[3][3], mesh const * m,
                         size_t element_id)
{

    static const double S_1[3][3] = { {  0.5 , -0.5 , 0.0 },{ -0.5 ,  0.5 , 0.0 },{  0.0 ,  0.0 , 0.0 } };
    static const double S_2[3][3] = { {  1.0 , -0.5 , -0.5 }, { -0.5 ,  0.0 ,  0.5 }, { -0.5 ,  0.5 ,  0.0 } };
    static const double S_3[3][3] = { {  0.5 ,  0.0 , -0.5 }, {  0.0 ,  0.0 ,  0.0 }, { -0.5 ,  0.0 ,  0.5 } };

    double g1 = 0.0, g2 = 0.0, g3 = 0.0;
    double det_B_inv = 0.0;
    double * local_verts[3] ;
    size_t i, j;

    for(i = 0; i < 3; ++i)
    {
      local_verts[i] = &m->coords[2 * m->t2v[3 * element_id + i]];

      //std::cout<<"ele id: "<<element_id<<std::endl;
      //std::cout<<"t2v: "<<m->t2v[3 * element_id + i]<<std::endl;
      //std::cout<<"m coord: "<<&m->coords[2 * m->t2v[3 * element_id + i]]<<std::endl;


      //std::cout<<"Local verts at i: "<<local_verts[i][0]<<std::endl;
      //std::cout<<"Local verts at i: "<<local_verts[i][1]<<std::endl;

    }

    det_B_inv = 1.0 / fabs( (local_verts[1][0] - local_verts[0][0]) *(local_verts[2][1] - local_verts[0][1]) -
                           (local_verts[1][1] - local_verts[0][1]) *(local_verts[2][0] - local_verts[0][0]) );


    //std::cout<<"Det B inverse: "<<det_B_inv<<std::endl;

    g1 =  det_B_inv * ( (local_verts[2][0] - local_verts[0][0]) *(local_verts[2][0] - local_verts[0][0]) +
                             (local_verts[2][1] - local_verts[0][1]) *(local_verts[2][1] - local_verts[0][1]) );
    g2 = -det_B_inv * ( (local_verts[1][0] - local_verts[0][0]) * (local_verts[2][0] - local_verts[0][0]) +
                             (local_verts[1][1] - local_verts[0][1]) *(local_verts[2][1] - local_verts[0][1]) );
    g3 =  det_B_inv * ( (local_verts[1][0] - local_verts[0][0]) * (local_verts[1][0] - local_verts[0][0]) +
                             (local_verts[1][1] - local_verts[0][1]) *(local_verts[1][1] - local_verts[0][1]) );

    //std::cout<<"g1: "<<g1<<" "<<"g2: "<<g2<<" "<<"g3: "<<g3<<std::endl;

    for (i = 0; i < 3; ++i)
    {
      for (j = 0; j < 3; ++j)
      {
        local_stiffness[i][j] = g1 * S_1[i][j] + g2 * S_2[i][j] + g3 * S_3[i][j];
      }
    }
}

extern "C" void getLocalLoad(double local_load[3], mesh const * m, size_t element_id,
                    double (*fn_f)(double, double))
{

  double det_B;
  double * local_verts[3];
  size_t i;

  for(i = 0; i < 3; ++i)
  {
    local_verts[i] = &m->coords[2 * m->t2v[3 * element_id + i]];
  }

  det_B = fabs( (local_verts[1][0] - local_verts[0][0]) *(local_verts[2][1] - local_verts[0][1]) -
                (local_verts[1][1] - local_verts[0][1]) *(local_verts[2][0] - local_verts[0][0]) );

  // Applying Trapezoidal rule
  for (i = 0; i < 3; ++i)
  {
    local_load[i] = det_B / 6.0 * fn_f(local_verts[i][0], local_verts[i][1]);
  }
}

extern "C" void assembleLocal2globalStiffness(double local_stiffness[3][3],
                                     crs_matrix * mat, mesh const * m,
                                     size_t element_id)
{

  size_t i, j, ind;
  size_t global_i, global_j;

  for (i = 0; i < 3; ++i)
  {
    global_i = m->t2v[3 * element_id + i];

    for (j = 0; j < 3; ++j)
    {
      global_j = m->t2v[3 * element_id + j];

      for (ind = mat->rowPtr[global_i]; ind < mat->rowPtr[global_i + 1]; ++ind)
      {
        if (mat->colInd[ind] == global_j)
          break;
      }

      mat->val[ind] += local_stiffness[i][j];
    }
  }
}

extern "C" void assembleLocal2globalLoad(double local_load[3], double * rhs,
                                mesh const * m, size_t element_id)
{

  size_t i, global_i;

  if (rhs == NULL)
      err_exit("Rhs not given");

  for (i = 0; i < 3; ++i)
  {
    global_i = m->t2v[3 * element_id + i];

    rhs[global_i] += local_load[i];
  }
}

extern "C" void applyDbc(crs_matrix * mat, double * rhs, mesh const * m,
               double (fn_g)(unsigned char, double, double))
{
    //loop over vertices
    size_t j=0,col=0;
    double x=0,y=0;
    //std::cout<<m->n_vertices<<std::endl;

    for (size_t row=0; row<m->n_vertices; row++)
    {
            //find x,y coord of the vertex
            x=m->coords[2*row]; y=m->coords[2*row+1];

            //identify boundary nodes and check if it is not inside the domain

            if (m->id_v[row] != 0)
            {
                    //edit matrix with 1.0 only on diagonal for DBC

                    for (j=mat->rowPtr[row]; j<mat->rowPtr[row+1]; j++)
                    {
                            col = mat->colInd[j];
                            //if colIndex=row number, data value = 1.0 otherwise 0.0
                            if (col == row)
                            {
                                    mat->val[j]=1.0;
                            }
                            else
                            {
                                    mat->val[j]=0.0;
                            }

                    }

                    //edit force vector with dirichlet value fn_g(row,x,y)
                    rhs[row]=fn_g(m->id_v[row],x,y);

            }
    }
}

extern "C" void Solve(crs_matrix const * mat, double * u, double const * rhs)
{

    size_t it, k, i, ind;
    double a_kk = 0.0;

    for (it = 0; it < MAX_IT; ++it)
    {
      for (k = 0; k < mat->n_rows; ++k)
      {
        u[k] = rhs[k];
        for (ind = mat->rowPtr[k]; ind < mat->rowPtr[k+1]; ++ind)
        {
          i = mat->colInd[ind];
          if (i == k)
          {
            a_kk = mat->val[ind];
          }
          else
          {
            u[k] -= mat->val[ind] * u[i];
          }
        }
        u[k] /= a_kk;
      }
    }
}
