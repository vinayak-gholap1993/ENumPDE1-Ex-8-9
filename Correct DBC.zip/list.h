#ifndef LIST_H
#define LIST_H

#ifdef __cplusplus
extern "C" {
#endif

typedef struct ol_element{

    size_t node_val;
    struct ol_element * next;
    } list_element;

typedef struct {

    list_element * begin;
    size_t length;

} List;


void init_list(List * list);

void insert_list(List * list, size_t val);

#ifdef __cplusplus
}
#endif

#endif
