#include <stdio.h>
#include <stdlib.h>

#include "list.h"

#define err_exit(msg) \
  { fprintf(stderr, "ERROR: %s (%s:%d)\n", msg, __FILE__, __LINE__); exit(1); }

void init_list(List * list)
{
    list->begin = NULL;
    list->length = 0;
}

void insert_list(List * list, size_t val)
{
    list_element * it;
    list_element * temp;

    if(list == NULL)
        err_exit("Empty list or no list provided");


    /* find the position in list where to insert the next value*/

    it = list->begin;
    if(it != NULL)
    {
        while(it->next != NULL && it->next->node_val <= val)
        {
            it = it->next;
        }
    }

    if (it == list->begin && (it == NULL || it->node_val > val) )
     {
       temp = list->begin;
       list->begin = (list_element *) malloc(sizeof(list_element));

       if (list->begin == NULL)
           err_exit("Insertion in the list failed!");
       list->begin->node_val = val;
       list->begin->next = temp;
       ++list->length;
     }
    else if (it->node_val != val)
      {
        temp = it->next;
        it->next = (list_element *) malloc(sizeof(list_element));

        if (it->next == NULL)
            err_exit("Insertion in the list failed!");
        it->next->node_val = val;
        it->next->next = temp;
        ++list->length;
      }


}
